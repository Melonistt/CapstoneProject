package com.example.capstoneproject.di

import android.content.Context
import com.example.capstoneproject.data.AppDatabase
import com.example.capstoneproject.data.AuthRepository
import com.example.capstoneproject.data.ExerciseDao
import com.example.capstoneproject.data.MealDao
import com.example.capstoneproject.data.ProfileDao
import com.example.capstoneproject.data.SessionDao
import com.example.capstoneproject.data.UserDao
import com.example.capstoneproject.data.WaterDao
import com.example.capstoneproject.data.WeightDao
import com.example.capstoneproject.data.WorkoutDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Optional - only needed if screens use Hilt (@AndroidEntryPoint + @Inject).
 * Without Hilt, just call AppDatabase.getInstance(context) directly.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        AppDatabase.getInstance(context)

    @Provides @Singleton
    fun provideAuthRepository(db: AppDatabase): AuthRepository = AuthRepository(db)

    @Provides fun provideUserDao(db: AppDatabase): UserDao = db.userDao()
    @Provides fun provideProfileDao(db: AppDatabase): ProfileDao = db.profileDao()
    @Provides fun provideMealDao(db: AppDatabase): MealDao = db.mealDao()
    @Provides fun provideWaterDao(db: AppDatabase): WaterDao = db.waterDao()
    @Provides fun provideWeightDao(db: AppDatabase): WeightDao = db.weightDao()
    @Provides fun provideExerciseDao(db: AppDatabase): ExerciseDao = db.exerciseDao()
    @Provides fun provideWorkoutDao(db: AppDatabase): WorkoutDao = db.workoutDao()
    @Provides fun provideSessionDao(db: AppDatabase): SessionDao = db.sessionDao()
}
