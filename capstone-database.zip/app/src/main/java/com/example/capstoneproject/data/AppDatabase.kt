package com.example.capstoneproject.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        UserProfile::class,
        Meal::class,
        WaterLog::class,
        WeightEntry::class,
        Exercise::class,
        Workout::class,
        WorkoutExercise::class,
        WorkoutSession::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun profileDao(): ProfileDao
    abstract fun mealDao(): MealDao
    abstract fun waterDao(): WaterDao
    abstract fun weightDao(): WeightDao
    abstract fun exerciseDao(): ExerciseDao
    abstract fun workoutDao(): WorkoutDao
    abstract fun sessionDao(): SessionDao

    companion object {
        private const val DB_NAME = "wellness.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Works with or without Hilt: AppDatabase.getInstance(requireContext()).mealDao()...
         * The demo data in DatabaseSeeder is inserted the first time the database is created.
         */
        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: build(context.applicationContext).also { INSTANCE = it }
            }

        private fun build(appContext: Context): AppDatabase =
            Room.databaseBuilder(appContext, AppDatabase::class.java, DB_NAME)
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                            DatabaseSeeder.seed(getInstance(appContext))
                        }
                    }
                })
                // Prototype setting: if the schema version changes, wipe and re-seed instead of
                // needing migrations. Remove before anything with real user data.
                .fallbackToDestructiveMigration(dropAllTables = true)
                .build()
    }
}
