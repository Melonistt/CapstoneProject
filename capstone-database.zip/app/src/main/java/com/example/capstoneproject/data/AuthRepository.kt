package com.example.capstoneproject.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface AuthResult {
    data class Success(val user: User) : AuthResult
    data class Error(val message: String) : AuthResult
}

/**
 * Local (on-device) login/registration.
 *
 * Usage from LoginActivity.performLogin():
 *   lifecycleScope.launch {
 *       when (val r = AuthRepository(AppDatabase.getInstance(this@LoginActivity)).login(email, password)) {
 *           is AuthResult.Success -> { /* save r.user.id (e.g. DataStore if rememberMe), go to MainActivity */ }
 *           is AuthResult.Error   -> passwordInputLayout.error = r.message
 *       }
 *   }
 */
class AuthRepository(private val db: AppDatabase) {

    suspend fun register(
        email: String,
        password: String,
        firstName: String,
        lastName: String
    ): AuthResult {
        val cleanEmail = email.trim().lowercase()
        if (password.length < 8) return AuthResult.Error("Password must be at least 8 characters")
        if (db.userDao().getByEmail(cleanEmail) != null) {
            return AuthResult.Error("An account with this email already exists")
        }
        val salt = PasswordHasher.newSalt()
        val hash = withContext(Dispatchers.Default) { PasswordHasher.hash(password, salt) }
        val user = User(
            email = cleanEmail,
            passwordHash = hash,
            passwordSalt = salt,
            firstName = firstName.trim(),
            lastName = lastName.trim()
        )
        val id = db.userDao().insert(user)
        db.profileDao().upsert(UserProfile(userId = id))   // blank profile, filled in during setup
        return AuthResult.Success(user.copy(id = id))
    }

    suspend fun login(email: String, password: String): AuthResult {
        val user = db.userDao().getByEmail(email.trim().lowercase())
            ?: return AuthResult.Error("Invalid email or password")
        val ok = withContext(Dispatchers.Default) {
            PasswordHasher.verify(password, user.passwordSalt, user.passwordHash)
        }
        // Same message either way so the screen doesn't reveal which emails exist.
        return if (ok) AuthResult.Success(user) else AuthResult.Error("Invalid email or password")
    }
}
