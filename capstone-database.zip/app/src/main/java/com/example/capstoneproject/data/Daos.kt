package com.example.capstoneproject.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/*
 * Conventions:
 *  - Flow<...>       -> observe from the UI (collect in viewLifecycleOwner.lifecycleScope);
 *                       re-emits automatically when the table changes.
 *  - suspend fun     -> one-off read/write; call from a coroutine (never the main thread directly).
 *  - start/end args  -> epoch millis; use DateRange.today(), DateRange.lastDays(7), etc.
 */

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(user: User): Long

    @Update
    suspend fun update(user: User)

    @Query("SELECT * FROM users WHERE email = :email COLLATE NOCASE LIMIT 1")
    suspend fun getByEmail(email: String): User?

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getById(id: Long): User?

    @Query("SELECT * FROM users WHERE id = :id")
    fun observeById(id: Long): Flow<User?>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int

    @Query("DELETE FROM users WHERE id = :id")  // cascades to every table below
    suspend fun deleteById(id: Long)
}

@Dao
interface ProfileDao {
    @Upsert
    suspend fun upsert(profile: UserProfile)

    @Query("SELECT * FROM user_profiles WHERE userId = :userId")
    fun observe(userId: Long): Flow<UserProfile?>

    @Query("SELECT * FROM user_profiles WHERE userId = :userId")
    suspend fun get(userId: Long): UserProfile?

    @Query("UPDATE user_profiles SET notificationsEnabled = :enabled, updatedAt = CAST(strftime('%s','now') AS INTEGER) * 1000 WHERE userId = :userId")
    suspend fun setNotifications(userId: Long, enabled: Boolean)

    @Query("UPDATE user_profiles SET detailedMetricsEnabled = :enabled, updatedAt = CAST(strftime('%s','now') AS INTEGER) * 1000 WHERE userId = :userId")
    suspend fun setDetailedMetrics(userId: Long, enabled: Boolean)

    @Query("UPDATE user_profiles SET darkModeEnabled = :enabled, updatedAt = CAST(strftime('%s','now') AS INTEGER) * 1000 WHERE userId = :userId")
    suspend fun setDarkMode(userId: Long, enabled: Boolean)
}

@Dao
interface MealDao {
    @Insert
    suspend fun insert(meal: Meal): Long

    @Insert
    suspend fun insertAll(meals: List<Meal>)

    @Update
    suspend fun update(meal: Meal)

    @Delete
    suspend fun delete(meal: Meal)

    @Query("""
        SELECT * FROM meals
        WHERE userId = :userId AND loggedAt BETWEEN :start AND :end
        ORDER BY loggedAt DESC
    """)
    fun observeBetween(userId: Long, start: Long, end: Long): Flow<List<Meal>>

    /** Home screen: "Consumed today" + macro line. */
    @Query("""
        SELECT COALESCE(SUM(calories), 0) AS calories,
               COALESCE(SUM(proteinG), 0) AS proteinG,
               COALESCE(SUM(carbsG), 0)   AS carbsG,
               COALESCE(SUM(fatG), 0)     AS fatG
        FROM meals
        WHERE userId = :userId AND loggedAt BETWEEN :start AND :end
    """)
    fun observeTotals(userId: Long, start: Long, end: Long): Flow<NutritionTotals>

    /** Progress screen: "This Week" calories per day. */
    @Query("""
        SELECT strftime('%Y-%m-%d', loggedAt / 1000, 'unixepoch', 'localtime') AS day,
               SUM(calories) AS calories
        FROM meals
        WHERE userId = :userId AND loggedAt >= :since
        GROUP BY day
        ORDER BY day
    """)
    fun observeDailyCalories(userId: Long, since: Long): Flow<List<DailyCalories>>
}

@Dao
interface WaterDao {
    @Insert
    suspend fun insert(log: WaterLog): Long

    @Insert
    suspend fun insertAll(logs: List<WaterLog>)

    /** Home screen: "4 / 8 cups" (the 8 comes from UserProfile.dailyWaterGoalCups). */
    @Query("""
        SELECT COALESCE(SUM(cups), 0) FROM water_logs
        WHERE userId = :userId AND loggedAt BETWEEN :start AND :end
    """)
    fun observeCups(userId: Long, start: Long, end: Long): Flow<Int>
}

@Dao
interface WeightDao {
    @Insert
    suspend fun insert(entry: WeightEntry): Long

    @Insert
    suspend fun insertAll(entries: List<WeightEntry>)

    /** Weight chart, oldest first. */
    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY recordedAt ASC")
    fun observeAll(userId: Long): Flow<List<WeightEntry>>

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY recordedAt ASC LIMIT 1")
    suspend fun first(userId: Long): WeightEntry?

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY recordedAt DESC LIMIT 1")
    suspend fun latest(userId: Long): WeightEntry?
}

@Dao
interface ExerciseDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(exercises: List<Exercise>): List<Long>

    @Query("SELECT * FROM exercises ORDER BY name")
    fun observeAll(): Flow<List<Exercise>>

    @Query("SELECT * FROM exercises WHERE videoTitle IS NOT NULL ORDER BY name")
    fun observeWithVideos(): Flow<List<Exercise>>

    @Query("SELECT * FROM exercises WHERE name = :name LIMIT 1")
    suspend fun getByName(name: String): Exercise?
}

@Dao
interface WorkoutDao {
    @Insert
    suspend fun insert(workout: Workout): Long

    @Update
    suspend fun update(workout: Workout)

    @Delete
    suspend fun delete(workout: Workout)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(links: List<WorkoutExercise>)

    /** Train screen roster: built-in routines + this user's custom ones, minus hidden. */
    @Transaction
    @Query("""
        SELECT * FROM workouts
        WHERE (userId IS NULL OR userId = :userId) AND isHidden = 0
        ORDER BY createdAt
    """)
    fun observeRoster(userId: Long): Flow<List<WorkoutWithExercises>>

    /** Settings: list of hidden routines so the user can restore them. */
    @Query("SELECT * FROM workouts WHERE (userId IS NULL OR userId = :userId) AND isHidden = 1")
    fun observeHidden(userId: Long): Flow<List<Workout>>

    @Query("UPDATE workouts SET isHidden = :hidden WHERE id = :workoutId")
    suspend fun setHidden(workoutId: Long, hidden: Boolean)

    @Transaction
    @Query("SELECT * FROM workouts WHERE id = :workoutId")
    suspend fun getWithExercises(workoutId: Long): WorkoutWithExercises?
}

@Dao
interface SessionDao {
    @Insert
    suspend fun insert(session: WorkoutSession): Long

    @Insert
    suspend fun insertAll(sessions: List<WorkoutSession>)

    /** Progress screen: "24 Workouts". */
    @Query("SELECT COUNT(*) FROM workout_sessions WHERE userId = :userId AND completed = 1")
    fun observeCompletedCount(userId: Long): Flow<Int>

    /** Progress screen: "2,450 Calories" burned. */
    @Query("SELECT COALESCE(SUM(caloriesBurned), 0) FROM workout_sessions WHERE userId = :userId AND completed = 1")
    fun observeCaloriesBurned(userId: Long): Flow<Int>

    /** Did the user train today? (Home "Today's Plan" -> Workout vs Rest day.) */
    @Query("""
        SELECT COUNT(*) FROM workout_sessions
        WHERE userId = :userId AND completed = 1 AND startedAt BETWEEN :start AND :end
    """)
    fun observeCountBetween(userId: Long, start: Long, end: Long): Flow<Int>

    /** Distinct active days (logged a meal or trained), newest first - feed to Streaks.current(). */
    @Query("""
        SELECT day FROM (
            SELECT strftime('%Y-%m-%d', startedAt / 1000, 'unixepoch', 'localtime') AS day
            FROM workout_sessions WHERE userId = :userId AND completed = 1
            UNION
            SELECT strftime('%Y-%m-%d', loggedAt / 1000, 'unixepoch', 'localtime') AS day
            FROM meals WHERE userId = :userId
        ) ORDER BY day DESC
    """)
    fun observeActiveDays(userId: Long): Flow<List<String>>
}
