package com.example.capstoneproject.data

import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Start/end millis for common date windows, in device local time. (Calendar keeps minSdk 24 happy.) */
data class DateRange(val start: Long, val end: Long) {
    companion object {
        fun today(): DateRange = dayOf(System.currentTimeMillis())

        fun dayOf(millis: Long): DateRange {
            val cal = Calendar.getInstance().apply {
                timeInMillis = millis
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val start = cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
            return DateRange(start, cal.timeInMillis - 1)
        }

        /** The last [days] days including today, e.g. lastDays(7) for "This Week". */
        fun lastDays(days: Int): DateRange {
            val todayRange = today()
            val cal = Calendar.getInstance().apply {
                timeInMillis = todayRange.start
                add(Calendar.DAY_OF_YEAR, -(days - 1))
            }
            return DateRange(cal.timeInMillis, todayRange.end)
        }

        /** Millis for [daysAgo] days ago at a given time of day - handy for seeding/testing. */
        fun daysAgoAt(daysAgo: Int, hour: Int, minute: Int = 0): Long =
            Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -daysAgo)
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
    }
}

object Streaks {
    /**
     * Current streak from SessionDao.observeActiveDays() output ("yyyy-MM-dd", newest first).
     * Counts consecutive days ending today (or yesterday, so the streak isn't "lost" before you log today).
     */
    fun current(activeDaysDesc: List<String>): Int {
        if (activeDaysDesc.isEmpty()) return 0
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val days = activeDaysDesc.toSet()
        val cal = Calendar.getInstance()
        if (fmt.format(cal.time) !in days) cal.add(Calendar.DAY_OF_YEAR, -1)
        var streak = 0
        while (fmt.format(cal.time) in days) {
            streak++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return streak
    }
}

/**
 * Salted PBKDF2 password hashing (planning report risk R3: "password hashing").
 * PBKDF2WithHmacSHA1 is used because it is available on every API level >= 24.
 * CPU-heavy: call from Dispatchers.Default (AuthRepository already does).
 */
object PasswordHasher {
    private const val ITERATIONS = 60_000
    private const val KEY_LENGTH_BITS = 256

    fun newSalt(): String = ByteArray(16).also { SecureRandom().nextBytes(it) }.toHex()

    fun hash(password: String, salt: String): String {
        val spec = PBEKeySpec(password.toCharArray(), salt.hexToBytes(), ITERATIONS, KEY_LENGTH_BITS)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded.toHex()
        } finally {
            spec.clearPassword()
        }
    }

    fun verify(password: String, salt: String, expectedHash: String): Boolean =
        MessageDigest.isEqual(hash(password, salt).toByteArray(), expectedHash.toByteArray())

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun String.hexToBytes(): ByteArray =
        ByteArray(length / 2) { i -> substring(i * 2, i * 2 + 2).toInt(16).toByte() }
}
