package com.example.capstoneproject.data

import com.example.capstoneproject.data.DateRange.Companion.daysAgoAt

/**
 * Demo data so every screen has something real to show.
 *
 *   Demo login:  demo@wellness.app  /  Password123
 *
 * Numbers line up with the current mockups: 2,300 kcal target with 450 eaten today
 * (= 1,850 remaining), 4 / 8 cups of water, 72 kg now vs 68 kg goal (down 4 kg),
 * 24 workouts / 2,450 kcal burned, and the two roster routines on the Train screen.
 */
object DatabaseSeeder {

    const val DEMO_EMAIL = "demo@wellness.app"
    const val DEMO_PASSWORD = "Password123"

    suspend fun seed(db: AppDatabase) {
        if (db.userDao().count() > 0) return   // already seeded

        // ---- User + profile
        val salt = PasswordHasher.newSalt()
        val userId = db.userDao().insert(
            User(
                email = DEMO_EMAIL,
                passwordHash = PasswordHasher.hash(DEMO_PASSWORD, salt),
                passwordSalt = salt,
                firstName = "Alex",
                lastName = "Demo"
            )
        )
        db.profileDao().upsert(
            UserProfile(
                userId = userId,
                age = 28,
                gender = "other",
                heightCm = 178.0,
                weightKg = 72.0,
                goalWeightKg = 68.0,
                fitnessGoal = "weight_loss",
                activityLevel = "lightly_active",
                experience = "intermediate",
                dailyCalorieTarget = 2300,
                dailyWaterGoalCups = 8
            )
        )

        // ---- Exercise library
        db.exerciseDao().insertAll(
            listOf(
                Exercise(name = "Bench press", muscleGroup = "Chest",
                    instructions = "Lie flat, grip just wider than shoulders, lower the bar to mid-chest, press up.",
                    videoTitle = "Bench press form guide", videoLength = "4:32"),
                Exercise(name = "Rows", muscleGroup = "Back",
                    instructions = "Hinge at the hips, flat back, pull the weight to your lower ribs, lower slowly."),
                Exercise(name = "Shoulder press", muscleGroup = "Shoulders",
                    instructions = "Press the weights from shoulder height to overhead without arching your back."),
                Exercise(name = "Pull-ups", muscleGroup = "Back",
                    instructions = "Hang with straight arms, pull until your chin clears the bar, lower under control."),
                Exercise(name = "Squats", muscleGroup = "Legs",
                    instructions = "Feet shoulder-width apart, sit back and down until thighs are parallel, drive up.",
                    videoTitle = "Perfect squat technique", videoLength = "6:15"),
                Exercise(name = "Deadlifts", muscleGroup = "Legs",
                    instructions = "Bar over mid-foot, flat back, push the floor away and stand tall, lower with control.",
                    videoTitle = "Deadlift fundamentals", videoLength = "5:48"),
                Exercise(name = "Lunges", muscleGroup = "Legs",
                    instructions = "Step forward, lower until both knees are at 90 degrees, push back to standing."),
                Exercise(name = "Running", muscleGroup = "Cardio",
                    instructions = "Easy conversational pace for 15-20 minutes, or intervals if you're feeling good.")
            )
        )
        suspend fun ex(name: String) = db.exerciseDao().getByName(name)!!.id

        // ---- Built-in roster routines (userId = null -> available to everyone)
        val upperId = db.workoutDao().insert(
            Workout(
                name = "Upper body strength",
                focus = "Chest, Shoulders, Triceps",
                description = "Compound pushing and pulling for upper-body strength.",
                scheduledDays = "Mon,Wed,Fri",
                durationMin = 45
            )
        )
        val lowerId = db.workoutDao().insert(
            Workout(
                name = "Lower body/cardio",
                focus = "Legs, Glutes, Cardio",
                description = "Leg strength finished with a short run.",
                scheduledDays = "Tue,Thu,Sat",
                durationMin = 50
            )
        )
        db.workoutDao().insertExercises(
            listOf(
                WorkoutExercise(upperId, ex("Bench press"), position = 0, sets = 4, reps = 8),
                WorkoutExercise(upperId, ex("Rows"), position = 1, sets = 4, reps = 10),
                WorkoutExercise(upperId, ex("Shoulder press"), position = 2, sets = 3, reps = 10),
                WorkoutExercise(upperId, ex("Pull-ups"), position = 3, sets = 3, reps = 8),
                WorkoutExercise(lowerId, ex("Squats"), position = 0, sets = 4, reps = 8),
                WorkoutExercise(lowerId, ex("Deadlifts"), position = 1, sets = 3, reps = 6),
                WorkoutExercise(lowerId, ex("Lunges"), position = 2, sets = 3, reps = 12),
                WorkoutExercise(lowerId, ex("Running"), position = 3, sets = 1, reps = 1)
            )
        )

        // ---- Workout history: 24 sessions over ~8 weeks, 2,450 kcal total
        db.sessionDao().insertAll(
            (0 until 24).map { i ->
                WorkoutSession(
                    userId = userId,
                    workoutId = if (i % 2 == 0) upperId else lowerId,
                    startedAt = daysAgoAt(daysAgo = 1 + i * 2, hour = 17, minute = 30),
                    durationMin = if (i % 2 == 0) 45 else 50,
                    caloriesBurned = if (i == 0) 104 else 102,
                    completed = true
                )
            }
        )

        // ---- Weight trend: 76 kg five weeks ago down to 72 kg today
        db.weightDao().insertAll(
            listOf(76.0, 75.1, 74.4, 73.6, 72.8, 72.0).mapIndexed { i, kg ->
                WeightEntry(userId = userId, weightKg = kg, recordedAt = daysAgoAt((5 - i) * 7, hour = 7))
            }
        )

        // ---- Meals: today = 450 kcal so far; previous 6 days = full days
        val meals = mutableListOf(
            Meal(userId = userId, name = "Oats with banana", mealType = "breakfast",
                calories = 340, proteinG = 12.0, carbsG = 58.0, fatG = 8.0, loggedAt = daysAgoAt(0, 7, 30)),
            Meal(userId = userId, name = "Greek yoghurt", mealType = "snack",
                calories = 110, proteinG = 10.0, carbsG = 8.0, fatG = 4.0, loggedAt = daysAgoAt(0, 10, 15))
        )
        for (d in 1..6) {
            meals += Meal(userId = userId, name = "Oats with banana", mealType = "breakfast",
                calories = 340, proteinG = 12.0, carbsG = 58.0, fatG = 8.0, loggedAt = daysAgoAt(d, 7, 30))
            meals += Meal(userId = userId, name = "Grilled chicken/rice", mealType = "lunch",
                calories = 520, proteinG = 42.0, carbsG = 45.0, fatG = 18.0, loggedAt = daysAgoAt(d, 12, 30))
            meals += Meal(userId = userId, name = "Protein shake", mealType = "snack",
                calories = 180 + d * 10, proteinG = 25.0, carbsG = 9.0, fatG = 3.0, loggedAt = daysAgoAt(d, 15, 30))
            meals += Meal(userId = userId, name = "Salmon, potatoes & greens", mealType = "dinner",
                calories = 650 + d * 20, proteinG = 38.0, carbsG = 52.0, fatG = 24.0, loggedAt = daysAgoAt(d, 19, 0))
        }
        db.mealDao().insertAll(meals)

        // ---- Water: 4 cups today, a few days of history
        db.waterDao().insertAll(
            (0 until 4).map { WaterLog(userId = userId, cups = 1, loggedAt = daysAgoAt(0, 8 + it * 2)) } +
                (1..6).map { d -> WaterLog(userId = userId, cups = 6 + d % 3, loggedAt = daysAgoAt(d, 20)) }
        )
    }
}
