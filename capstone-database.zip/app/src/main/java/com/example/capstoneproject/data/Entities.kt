package com.example.capstoneproject.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Junction
import androidx.room.PrimaryKey
import androidx.room.Relation

/*
 * All timestamps are epoch milliseconds (Long) so no TypeConverters are needed.
 * "Enum-like" fields are stored as plain strings - allowed values are noted beside each one.
 */

// ---------------------------------------------------------------- Users & profile

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true)]
)
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val email: String,
    val passwordHash: String,          // PBKDF2 hash, never the plain password
    val passwordSalt: String,
    val firstName: String,
    val lastName: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "user_profiles",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["id"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class UserProfile(
    @PrimaryKey val userId: Long,
    val age: Int? = null,
    val gender: String? = null,                 // "male", "female", "other"
    val heightCm: Double? = null,
    val weightKg: Double? = null,               // latest weight (kept in sync with weight_entries)
    val goalWeightKg: Double? = null,
    val fitnessGoal: String = "maintenance",    // "weight_loss", "muscle_gain", "maintenance"
    val activityLevel: String = "lightly_active", // "sedentary", "lightly_active", "active", "very_active"
    val experience: String = "beginner",        // "beginner", "intermediate", "advanced"
    val dietaryPreferences: String = "",        // comma-separated, e.g. "vegetarian,low_carb"
    val dailyCalorieTarget: Int = 2300,
    val dailyWaterGoalCups: Int = 8,
    // Profile screen switches
    val notificationsEnabled: Boolean = true,
    val detailedMetricsEnabled: Boolean = false,
    val darkModeEnabled: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

// ---------------------------------------------------------------- Nutrition

@Entity(
    tableName = "meals",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["id"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["userId", "loggedAt"])]
)
data class Meal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val name: String,                  // "Grilled chicken/rice"
    val mealType: String = "snack",    // "breakfast", "lunch", "dinner", "snack"
    val calories: Int,
    val proteinG: Double = 0.0,
    val carbsG: Double = 0.0,
    val fatG: Double = 0.0,
    val source: String = "manual",     // "manual" or "photo" (computer vision)
    val confidence: Double = 1.0,      // 1.0 for manual; CV estimate for photo
    val loggedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "water_logs",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["id"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["userId", "loggedAt"])]
)
data class WaterLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val cups: Int = 1,                 // use -1 to "deduct" a mistaken cup
    val loggedAt: Long = System.currentTimeMillis()
)

// ---------------------------------------------------------------- Progress

@Entity(
    tableName = "weight_entries",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["id"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["userId", "recordedAt"])]
)
data class WeightEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val weightKg: Double,
    val notes: String = "",
    val recordedAt: Long = System.currentTimeMillis()
)

// ---------------------------------------------------------------- Training

/** Exercise library entry (shared by everyone). */
@Entity(
    tableName = "exercises",
    indices = [Index(value = ["name"], unique = true)]
)
data class Exercise(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,                  // "Bench press"
    val muscleGroup: String,           // "Chest"
    val instructions: String,
    val videoTitle: String? = null,    // "Bench press form guide"
    val videoLength: String? = null,   // "4:32"
    val videoUrl: String? = null
)

/**
 * A routine on the Train screen.
 * userId = null  -> built-in routine available to every user
 * userId = <id>  -> custom routine made with "Build new routine"
 */
@Entity(
    tableName = "workouts",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["id"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["userId"])]
)
data class Workout(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long? = null,
    val name: String,                  // "Upper body strength"
    val focus: String = "",            // "Chest, Shoulders, Triceps"
    val description: String = "",
    val scheduledDays: String = "",    // "Mon,Wed,Fri"
    val durationMin: Int = 45,
    val isHidden: Boolean = false,     // "remove from roster" (reversible in settings)
    val createdAt: Long = System.currentTimeMillis()
)

/** Join table: which exercises are in which workout, in what order. */
@Entity(
    tableName = "workout_exercises",
    primaryKeys = ["workoutId", "exerciseId"],
    foreignKeys = [
        ForeignKey(
            entity = Workout::class,
            parentColumns = ["id"],
            childColumns = ["workoutId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Exercise::class,
            parentColumns = ["id"],
            childColumns = ["exerciseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["exerciseId"])]
)
data class WorkoutExercise(
    val workoutId: Long,
    val exerciseId: Long,
    val position: Int = 0,
    val sets: Int = 3,
    val reps: Int = 10
)

/** One completed (or abandoned) workout - feeds the Progress screen counters. */
@Entity(
    tableName = "workout_sessions",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Workout::class,
            parentColumns = ["id"],
            childColumns = ["workoutId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index(value = ["userId", "startedAt"]), Index(value = ["workoutId"])]
)
data class WorkoutSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val workoutId: Long?,
    val startedAt: Long = System.currentTimeMillis(),
    val durationMin: Int = 0,
    val caloriesBurned: Int = 0,
    val completed: Boolean = true
)

// ---------------------------------------------------------------- Query result shapes (not tables)

/** A workout plus its ordered exercise list - what the roster card needs. */
data class WorkoutWithExercises(
    @Embedded val workout: Workout,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = WorkoutExercise::class,
            parentColumn = "workoutId",
            entityColumn = "exerciseId"
        )
    )
    val exercises: List<Exercise>
)

/** "Bench press, Rows, Shoulder press, Pull-ups" style summary for the roster card. */
fun WorkoutWithExercises.exerciseSummary(): String = exercises.joinToString(", ") { it.name }

data class NutritionTotals(
    val calories: Int,
    val proteinG: Double,
    val carbsG: Double,
    val fatG: Double
)

/** day = "yyyy-MM-dd" in device local time. */
data class DailyCalories(
    val day: String,
    val calories: Int
)
