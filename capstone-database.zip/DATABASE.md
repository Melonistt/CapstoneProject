# Database layer (Room) — drop-in

On-device SQLite via Room, which the project already has (Room 2.8.5 + KSP + Hilt in `build.gradle.kts`). **No Gradle changes needed.**

## Install

Copy into the repo, keeping the paths:

```
app/src/main/java/com/example/capstoneproject/data/   (6 files)
app/src/main/java/com/example/capstoneproject/di/DatabaseModule.kt   (optional, Hilt only)
```

Build → Make Project. The first time the app opens the DB, it seeds demo data:

**Demo login:** `demo@wellness.app` / `Password123`

The seed numbers match the current mockups: 2,300 kcal target with 450 eaten (1,850 remaining), 4/8 cups of water, 72 kg vs 68 kg goal, 24 workouts / 2,450 kcal, and the two roster routines.

To re-seed: uninstall the app, or Settings → Apps → Clear storage.

## Tables

| Table | What it holds | Screen |
|---|---|---|
| `users` | email, PBKDF2 password hash + salt, name | Login / Register |
| `user_profiles` | age, height, weight, goal weight, fitness goal, calorie & water targets, the 3 settings switches | Profile, Home |
| `meals` | name, type, calories, protein/carbs/fat, source (`manual`/`photo`), confidence, time | Meal, Home, Progress |
| `water_logs` | cups (+1 / −1), time | Home |
| `weight_entries` | kg, notes, time | Progress chart |
| `exercises` | library: name, muscle group, instructions, video title/length/url | Train → Exercise library |
| `workouts` | routines; `userId = null` = built-in, otherwise custom; `isHidden` = removed from roster | Train roster, Routine builder |
| `workout_exercises` | which exercises are in a routine, with sets/reps/order | Train |
| `workout_sessions` | completed workouts, duration, calories burned | Progress counters, streak |

Every user-owned table cascades on delete, so `userDao().deleteById(id)` covers "delete my data" (UC-11).

## Using it (no Hilt required)

```kotlin
val db = AppDatabase.getInstance(requireContext())
val userId = 1L  // logged-in user's id (save it at login, e.g. in DataStore)
val today = DateRange.today()

viewLifecycleOwner.lifecycleScope.launch {
    viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
        launch {
            db.mealDao().observeTotals(userId, today.start, today.end).collect { t ->
                consumedText.text = "${t.calories} kcal"
            }
        }
        launch {
            db.waterDao().observeCups(userId, today.start, today.end).collect { cups ->
                waterText.text = "$cups / 8 cups"
            }
        }
    }
}

// Writes are suspend functions:
lifecycleScope.launch {
    db.mealDao().insert(Meal(userId = userId, name = "Chicken wrap", mealType = "lunch",
        calories = 480, proteinG = 35.0, carbsG = 40.0, fatG = 15.0))
}
```

`Flow` queries update the UI automatically whenever data changes. For example, logging a meal updates the Home totals without any refresh code.

### Login

```kotlin
lifecycleScope.launch {
    when (val r = AuthRepository(AppDatabase.getInstance(this@LoginActivity)).login(email, password)) {
        is AuthResult.Success -> { /* store r.user.id, open MainActivity */ }
        is AuthResult.Error   -> passwordInputLayout.error = r.message
    }
}
```

`register(email, password, first, last)` creates the user and a blank profile.

### Handy queries per screen

- **Home:** `mealDao().observeTotals`, `waterDao().observeCups`, `profileDao().observe` (target), `sessionDao().observeCountBetween` (workout vs rest day)
- **Meal:** `mealDao().insert / observeBetween / update / delete`
- **Progress:** `weightDao().observeAll`, `mealDao().observeDailyCalories(userId, DateRange.lastDays(7).start)`, `sessionDao().observeCompletedCount / observeCaloriesBurned`, `Streaks.current(sessionDao().observeActiveDays(...))`
- **Train:** `workoutDao().observeRoster(userId)` (each item has `.exercises` + `.exerciseSummary()`), `exerciseDao().observeWithVideos()`, `workoutDao().setHidden`
- **Profile:** `userDao().observeById`, `profileDao().setNotifications / setDetailedMetrics / setDarkMode`

## Notes

- Timestamps are epoch millis (`Long`), so no type converters are needed.
- `fallbackToDestructiveMigration` is on. If you change an entity, bump `version` in `AppDatabase` and the DB is wiped and re-seeded. That's fine for the prototype.
- This is local storage only. The AI/API backend is separate and doesn't replace this. It can read from or write to these tables later.
